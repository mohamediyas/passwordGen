import "./App.css";
import React, { useState } from "react";

function App() {
  const [state, setState] = useState({
    capital: "",
    small: "",
    number: "",
  });

  const [result, setResult] = useState("");

  const [nextPage, setNextPage] = useState(false);

  const { capital, small, number } = state;

  const submit = (e) => {
    let length = 20;

    e.preventDefault();

    const symbols = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";

    const all = capital.toUpperCase() + small + number + symbols;

    let password = "";

    for (let i = 0; i < length; i++) {
      const randomNumber = Math.floor(Math.random() * length + 1);

      password += all.charAt(randomNumber);
    }

    setResult(password);

    setNextPage(true);
  };

  if (nextPage) {
    return (
      <div className="App">
        <header className="App-header">
          <h1>Your Password</h1>
          <div className="result">{result}</div>
        </header>
      </div>
    );
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>Devloper Coding Tricks</h1>
        <h2>Password Generator</h2>
        <form onSubmit={submit}>
          <div className="form-control">
            <label>Please Enter first words</label>
            <input
              value={state.capital}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  capital: e.target.value,
                }))
              }
              type="text"
            />
            <label>Please Enter Small words</label>
            <input
              value={state.small}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  small: e.target.value,
                }))
              }
              type="text"
            />
            <label>Please Enter Number</label>
            <input
              value={state.number}
              onChange={(e) =>
                setState((prevState) => ({
                  ...prevState,
                  number: e.target.value,
                }))
              }
              type="number"
            />

            <button type="submit">Submit</button>
          </div>
        </form>
      </header>
    </div>
  );
}

export default App;
